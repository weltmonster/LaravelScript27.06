@extends('frontend.layouts.app')

@section('content')

@endsection
