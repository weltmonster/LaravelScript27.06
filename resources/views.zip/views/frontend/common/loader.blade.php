<div id="loading-center">
    <div id="loading-center-absolute">
        {{-- <!-- loading content here --> --}}
        <div class="tp-preloader preloader-1">
            <div class="tp-preloader">
                <div class="tp-preloader">
                    <div class="tp-preloader">
                        <div class="tp-preloader">
                            <div class="tp-preloader">
                                <div class="tp-preloader">
                                    <div class="tp-preloader">
                                        <div class="tp-preloader">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        {{-- <!-- preloader style 2 --> --}}
        <div class="tp-preloader-2">
            <svg width="180" height="180" viewBox="0 0 100 100">
                <polyline class="line-cornered stroke-still" points="0,0 100,0 100,100" stroke-width="10" fill="none">
                </polyline>
                <polyline class="line-cornered stroke-still" points="0,0 0,100 100,100" stroke-width="10" fill="none">
                </polyline>
                <polyline class="line-cornered stroke-animation" points="0,0 100,0 100,100" stroke-width="10"
                    fill="none"></polyline>
                <polyline class="line-cornered stroke-animation" points="0,0 0,100 100,100" stroke-width="10"
                    fill="none"></polyline>
            </svg>
        </div>

        {{-- <!-- prealoader style 3 --> --}}
        <div class="tp-preloader-3">
            <div class="loader loader-1">
                <div class="loader-outter"></div>
                <div class="loader-inner"></div>
            </div>
        </div>
    </div>
</div>